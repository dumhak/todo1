
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.store.todo.jpa.Producto;
import org.store.todo.jpa.Tipo;
import org.store.todo.jpa.Unidad;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.todo.store.ejb.AdministrarProductosEjb;

import com.todo.etore.dto.ProductoDTO;

public class AdministrarProductosEjbTest {

	@PersistenceContext
	private EntityManager entityManager;

	@EJB
	private AdministrarProductosEjb administrarProductosEjb;

	@Test
	public void testAlmacenarSolcitudPrestacionEconomica() throws Exception {
		// Se verifica que se inyecte correctamente el EJB
		Assert.assertNotNull(administrarProductosEjb);
		List<ProductoDTO> listProductos = new ArrayList<ProductoDTO>();
		Producto producto = new Producto();
		Unidad unidad = new Unidad();
		Tipo tipo = new Tipo();
		producto.setIdProducto(-1L);
		producto.setCodigomanual("1231232");
		producto.setDescripcion("Descripciòn");
		unidad.setIdunidad(1L);
		producto.setIdunidad(unidad);
		tipo.setIdtipo(1L);
		producto.setIdtipo(tipo);
		producto.setValorUnitario(new BigDecimal("5000"));
		entityManager.merge(producto).getIdProducto();

		try {
			listProductos = administrarProductosEjb.consultarListaProductos();
			Assert.assertNotNull(listProductos,
					"Se encontró información  con el id " + listProductos.get(0).getIdProducto());
			Assert.assertEquals(listProductos.get(0).getCodigomanual(), "1231232", "Código manual");

		} catch (Exception e) {
			Assert.fail(e.getMessage(), e);
		}
	}

	@BeforeMethod
	public void beforeMethod() {
		//beginTransaction();
	}

	@AfterMethod
	public void afterMethod() {
		//rollback();
	}

}
