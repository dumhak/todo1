package org.todo.store.ejb;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.store.todo.jpa.Producto;
import org.store.todo.jpa.Tipo;
import org.store.todo.jpa.Unidad;

import com.todo.etore.dto.ProductoDTO;

/**
 * Session Bean implementation class AdministrarProductosEjb
 */
@Stateless
@Path("/AdministrarProductosEjb")
@LocalBean
public class AdministrarProductosEjb {

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Default constructor.
	 */
	public AdministrarProductosEjb() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/consultarListaProductos")
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<ProductoDTO> consultarListaProductos() {
		List<ProductoDTO> listProductos = new ArrayList<ProductoDTO>();
		ProductoDTO productoDTO;
		StringBuilder querySql;
		querySql = new StringBuilder();
		querySql.append(" SELECT p From Producto p ");
		Query query = entityManager.createQuery(querySql.toString());
		List<Producto> listaProductos = (List<Producto>) query.getResultList();

		if (!listaProductos.isEmpty()) {
			for (Producto producto : listaProductos) {
				productoDTO = new ProductoDTO();
				productoDTO.setIdProducto(producto.getIdProducto());
				productoDTO.setCodigomanual(producto.getCodigomanual());
				productoDTO.setDescripcion(producto.getDescripcion());
				productoDTO.setIdtipo(producto.getIdtipo().getIdtipo());
				productoDTO.setIdunidad(producto.getIdunidad().getIdunidad());
				productoDTO.setValorUnitario(producto.getValorUnitario());
			}
		}

		return listProductos;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/almacenarInformacionProductos")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Long almacenarInformacionProductos(ProductoDTO productoDTO) {
		Producto producto = new Producto();
		Unidad unidad = new Unidad();
		Tipo tipo = new Tipo();
		producto.setCodigomanual(productoDTO.getCodigomanual());
		producto.setDescripcion(productoDTO.getDescripcion());
		unidad.setIdunidad(productoDTO.getIdunidad());
		producto.setIdunidad(unidad);
		tipo.setIdtipo(productoDTO.getIdtipo());
		producto.setIdtipo(tipo);
		return entityManager.merge(producto).getIdProducto();

	}

}
