package com.todo.etore.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProductoDTO implements Serializable{
	private static final long serialVersionUID = 1L;

	private Long idProducto;

	private String codigomanual;

	private String descripcion;

	private Long idtipo;

	private Long idunidad;

	private BigDecimal valorUnitario;

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getCodigomanual() {
		return codigomanual;
	}

	public void setCodigomanual(String codigomanual) {
		this.codigomanual = codigomanual;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getIdtipo() {
		return idtipo;
	}

	public void setIdtipo(Long idtipo) {
		this.idtipo = idtipo;
	}

	public Long getIdunidad() {
		return idunidad;
	}

	public void setIdunidad(Long idunidad) {
		this.idunidad = idunidad;
	}

	public BigDecimal getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(BigDecimal valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	
}
