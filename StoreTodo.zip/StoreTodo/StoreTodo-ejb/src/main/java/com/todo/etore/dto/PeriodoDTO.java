package com.todo.etore.dto;

import java.io.Serializable;

public class PeriodoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idPeriodo;

	private String anio;
	private String cerrado;

	public Long getIdPeriodo() {
		return idPeriodo;
	}

	public void setIdPeriodo(Long idPeriodo) {
		this.idPeriodo = idPeriodo;
	}

	public String getAnio() {
		return anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCerrado() {
		return cerrado;
	}

	public void setCerrado(String cerrado) {
		this.cerrado = cerrado;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	private String mes;

}
