import { Component, OnInit } from '@angular/core';
import { ProductosDTO } from '../products';
import { Subject } from 'rxjs';
import { ProductoServicio } from '../services/producto.service';


@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

public products: ProductosDTO[] = [];

  

  constructor(private productoServicio:ProductoServicio) { 
       
   }

  ngOnInit() {
    this.consultarListoProductos();
  }

  private consultarListoProductos(): void {
    
    this.productoServicio.consultarProductos().subscribe(
        result => {
            if (result) {
                this.products = result;
              }

            
        }, error => {
          
        });

}

}
