import { Injectable, Injector } from '@angular/core';
import { Http, Response, RequestOptions, Headers, URLSearchParams, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import { ProductosDTO } from '../products';



export let WEB_CONTEXTS = {
    ADMINISTRACION: "StoreTodo-ejb",
  
};
@Injectable()
export class ProductoServicio extends AbstractService {

	constructor(injector: Injector) {
		super(injector);
	}

	
	public consultarProductos():Observable<ProductosDTO[]> {
		return this.get(WEB_CONTEXTS.ADMINISTRACION, "/AdministrarProductosEjb/consultarListaProductos");
	}
	
	public almacenarProductos(productos: ProductosDTO) {
		return this.post(WEB_CONTEXTS.ADMINISTRACION, "/AdministrarProductosEjb/almacenarInformacionProductos", productos);
	}

	


}