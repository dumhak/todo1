export class ProductosDTO {

    
    public idProducto: number;

    public codigomanual: string;

    public descripcion: string;

    public idtipo: number;

    public idunidad: number;

    public valorUnitario: number;
}
