package org.store.todo.jpa;

import java.io.Serializable;
import javax.persistence.*;



@Entity
@Table(name="Unidad")
@NamedQuery(name="Unidad.findAll", query="SELECT u FROM Unidad u")
public class Unidad implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "UNIDAD_GENERATOR", sequenceName = "SEC_UNIDAD", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "UNIDAD_GENERATOR")
	@Column(name="idunidad")
	private Long idunidad;

	@Column(name="unidad")
	private String unidad;

	public Unidad() {
	}

	
	public Long getIdunidad() {
		return idunidad;
	}


	public void setIdunidad(Long idunidad) {
		this.idunidad = idunidad;
	}


	public String getUnidad() {
		return this.unidad;
	}

	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}

}