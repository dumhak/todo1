package org.store.todo.jpa;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;



@Entity
@Table(name="Producto")
@NamedQuery(name="Producto.findAll", query="SELECT p FROM Producto p")
public class Producto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PRODUCTO_GENERATOR", sequenceName = "SEC_PRODUCTO", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODUCTO_GENERATOR")
	@Column(name="idProducto")
	private Long idProducto;
	
	@Column(name="codigomanual")
	private String codigomanual;

	@Column(name="descripcion")
	private String descripcion;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "idtipo")
	private Tipo idtipo;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "idunidad")
	private Unidad idunidad;

	@Column(name="valorUnitario")
	private BigDecimal valorUnitario;

	public Producto() {
	}

	public String getCodigomanual() {
		return this.codigomanual;
	}

	public void setCodigomanual(String codigomanual) {
		this.codigomanual = codigomanual;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}
	
	public Tipo getIdtipo() {
		return idtipo;
	}

	public void setIdtipo(Tipo idtipo) {
		this.idtipo = idtipo;
	}

	public Unidad getIdunidad() {
		return idunidad;
	}

	public void setIdunidad(Unidad idunidad) {
		this.idunidad = idunidad;
	}

	public BigDecimal getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(BigDecimal valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	
}