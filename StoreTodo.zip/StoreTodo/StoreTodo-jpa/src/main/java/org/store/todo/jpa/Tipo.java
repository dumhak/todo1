package org.store.todo.jpa;

import java.io.Serializable;
import javax.persistence.*;



@Entity
@Table(name="Tipo")
@NamedQuery(name="Tipo.findAll", query="SELECT t FROM Tipo t")
public class Tipo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TIPO_GENERATOR", sequenceName = "SEC_TIPO", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TIPO_GENERATOR")
	@Column(name="idtipo")
	private Long idtipo;

	@Column(name="tipo")
	private String tipo;

	public Tipo() {
	}

	public Long getIdtipo() {
		return this.idtipo;
	}

	public void setIdtipo(Long idtipo) {
		this.idtipo = idtipo;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}