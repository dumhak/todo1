package org.store.todo.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="PERIODO")
@NamedQuery(name="Periodo.findAll", query="SELECT p FROM Periodo p")
public class Periodo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PERIODO_GENERATOR", sequenceName = "SEC_PERIODO", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PERIODO_GENERATOR")
	@Column(name = "idPeriodo")
	private Long idPeriodo;
	
	@Column(name="anio")
	private String anio;

	@Column(name="cerrado")
	private String cerrado;

	@Column(name="mes")
	private String mes;

	public Periodo() {
	}

	public String getAnio() {
		return this.anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCerrado() {
		return this.cerrado;
	}

	public void setCerrado(String cerrado) {
		this.cerrado = cerrado;
	}

	
	public String getMes() {
		return this.mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public Long getIdPeriodo() {
		return idPeriodo;
	}

	public void setIdPeriodo(Long idPeriodo) {
		this.idPeriodo = idPeriodo;
	}
	
	

}